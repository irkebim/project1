# IRKE BIM Extension

This is the Blender Extension for BIM Modeling.
Built modularly for stability and future expansion.
